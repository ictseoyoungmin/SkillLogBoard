---
milestone: "v1.4"
phase: "Portable Report Maturity"
day: "day1"
slice: "01_static_output_inventory"
title: "static output inventory"
priority: "P0"
status: "pending"
target_version: "v1.4"
---

# 01_static_output_inventory — static output inventory

## Objective

Inventory existing static dashboard/report outputs and define which files belong to the portable evidence package.

## Context

v1.4 matures static dashboard/report outputs into portable, offline-friendly research evidence packages with manifests, figures, tables, and provenance metadata.

## Dependencies

- v1.3 Commercial Live UI completed or planned separately.
- Static dashboard/report outputs remain independent from the Live Board app.
- Report Artifact Layer v0.7+ concepts are available.

## Target Files

- src/skilllogboard/dashboard/
- src/skilllogboard/report/
- docs/report_artifacts.md
- docs/status_matrix.md

## Implementation Steps

1. List current dashboard/report files produced by examples and CLI.
2. Identify gaps: report_manifest, figures, tables, assets, provenance.
3. Define canonical report package layout.
4. Document compatibility with existing run folders.

## Acceptance Criteria

- Inventory is documented.
- Canonical report package layout is defined.
- Existing output paths remain compatible.

## Verification Commands

```bash
python - <<'PY'
from pathlib import Path
print('dashboard exists:', Path('src/skilllogboard/dashboard').exists())
print('report exists:', Path('src/skilllogboard/report').exists())
PY
```

## Non-goals

- Do not require the Live Board server to view static reports.
- Do not require external CDN/network access for portable reports.
- Do not replace report artifacts with screenshots only.
- Do not implement TensorBoard/W&B import.
- Do not implement Prometheus/Grafana integration.
- Do not implement cloud sync.
- Do not implement multi-user auth.
- Do not add a database backend.
- Do not perform TestPyPI/PyPI publishing in this slice.
- Do not weaken local-first, inspectable-file behavior.

## Handoff Notes

- Keep the slice focused and reviewable.
- Prefer additive metadata/state fields over breaking existing artifact contracts.
- Preserve the separation between portable static evidence and local Live Board app behavior.
- If an item is deferred, document the reason in the Agent Completion Block.
- Update related docs/status/changelog when user-visible behavior changes.

---

## Agent Completion Block

- [ ] Implementation completed
- [ ] Acceptance criteria verified
- [ ] Tests or smoke checks executed
- [ ] No unrelated files changed
- [ ] Notes added below if anything was skipped or deferred

**Status:** PENDING  
**Completed at:**  
**Completed by:**  
**Verification command(s):**  
**Notes:**  

<!-- AGENT_STATUS: PENDING -->

