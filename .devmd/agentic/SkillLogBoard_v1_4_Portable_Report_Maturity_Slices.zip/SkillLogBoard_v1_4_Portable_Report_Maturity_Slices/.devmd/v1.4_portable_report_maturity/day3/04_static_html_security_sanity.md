---
milestone: "v1.4"
phase: "Portable Report Maturity"
day: "day3"
slice: "04_static_html_security_sanity"
title: "static HTML security sanity"
priority: "P0"
status: "pending"
target_version: "v1.4"
---

# 04_static_html_security_sanity — static HTML security sanity

## Objective

Add basic safety checks for static HTML rendering.

## Context

v1.4 matures static dashboard/report outputs into portable, offline-friendly research evidence packages with manifests, figures, tables, and provenance metadata.

## Dependencies

- v1.3 Commercial Live UI completed or planned separately.
- Static dashboard/report outputs remain independent from the Live Board app.
- Report Artifact Layer v0.7+ concepts are available.

## Target Files

- src/skilllogboard/report/render.py
- tests/test_report_rendering.py
- docs/report_artifacts.md

## Implementation Steps

1. Escape user-provided strings in templates.
2. Avoid arbitrary raw HTML insertion unless explicitly marked safe.
3. Ensure local file paths are displayed as text, not executed.
4. Add tests with special characters.

## Acceptance Criteria

- Report rendering escapes unsafe text.
- No arbitrary script injection path is introduced.
- Tests pass.

## Verification Commands

```bash
pytest -q tests/test_report_rendering.py
```

## Non-goals

- Do not require the Live Board server to view static reports.
- Do not require external CDN/network access for portable reports.
- Do not replace report artifacts with screenshots only.
- Do not implement TensorBoard/W&B import.
- Do not implement Prometheus/Grafana integration.
- Do not implement cloud sync.
- Do not implement multi-user auth.
- Do not add a database backend.
- Do not perform TestPyPI/PyPI publishing in this slice.
- Do not weaken local-first, inspectable-file behavior.

## Handoff Notes

- Keep the slice focused and reviewable.
- Prefer additive metadata/state fields over breaking existing artifact contracts.
- Preserve the separation between portable static evidence and local Live Board app behavior.
- If an item is deferred, document the reason in the Agent Completion Block.
- Update related docs/status/changelog when user-visible behavior changes.

---

## Agent Completion Block

- [ ] Implementation completed
- [ ] Acceptance criteria verified
- [ ] Tests or smoke checks executed
- [ ] No unrelated files changed
- [ ] Notes added below if anything was skipped or deferred

**Status:** PENDING  
**Completed at:**  
**Completed by:**  
**Verification command(s):**  
**Notes:**  

<!-- AGENT_STATUS: PENDING -->

