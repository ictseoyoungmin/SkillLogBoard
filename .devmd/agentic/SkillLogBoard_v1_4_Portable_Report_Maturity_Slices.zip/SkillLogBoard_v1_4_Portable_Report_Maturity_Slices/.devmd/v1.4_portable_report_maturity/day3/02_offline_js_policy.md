---
milestone: "v1.4"
phase: "Portable Report Maturity"
day: "day3"
slice: "02_offline_js_policy"
title: "offline JS policy"
priority: "P0"
status: "pending"
target_version: "v1.4"
---

# 02_offline_js_policy — offline JS policy

## Objective

Define and implement offline JS policy for static reports.

## Context

v1.4 matures static dashboard/report outputs into portable, offline-friendly research evidence packages with manifests, figures, tables, and provenance metadata.

## Dependencies

- v1.3 Commercial Live UI completed or planned separately.
- Static dashboard/report outputs remain independent from the Live Board app.
- Report Artifact Layer v0.7+ concepts are available.

## Target Files

- src/skilllogboard/report/templates/
- src/skilllogboard/report/assets/
- tests/test_report_rendering.py
- docs/report_artifacts.md

## Implementation Steps

1. Ensure minimal mode does not require JS.
2. If portable_interactive mode exists, use vendored/inline JS only.
3. Do not use external CDN.
4. Document file-size tradeoff.
5. Add tests for no external script URLs.

## Acceptance Criteria

- Minimal mode works without JS.
- Interactive mode has no CDN dependency.
- Docs explain tradeoff.
- Tests pass.

## Verification Commands

```bash
pytest -q tests/test_report_rendering.py
```

## Non-goals

- Do not require the Live Board server to view static reports.
- Do not require external CDN/network access for portable reports.
- Do not replace report artifacts with screenshots only.
- Do not implement TensorBoard/W&B import.
- Do not implement Prometheus/Grafana integration.
- Do not implement cloud sync.
- Do not implement multi-user auth.
- Do not add a database backend.
- Do not perform TestPyPI/PyPI publishing in this slice.
- Do not weaken local-first, inspectable-file behavior.

## Handoff Notes

- Keep the slice focused and reviewable.
- Prefer additive metadata/state fields over breaking existing artifact contracts.
- Preserve the separation between portable static evidence and local Live Board app behavior.
- If an item is deferred, document the reason in the Agent Completion Block.
- Update related docs/status/changelog when user-visible behavior changes.

---

## Agent Completion Block

- [ ] Implementation completed
- [ ] Acceptance criteria verified
- [ ] Tests or smoke checks executed
- [ ] No unrelated files changed
- [ ] Notes added below if anything was skipped or deferred

**Status:** PENDING  
**Completed at:**  
**Completed by:**  
**Verification command(s):**  
**Notes:**  

<!-- AGENT_STATUS: PENDING -->

