---
milestone: "v1.5"
phase: "Performance, Retention, and Operational Rules"
day: "day2"
slice: "04_live_board_performance_docs"
title: "Live Board performance docs"
priority: "P0"
status: "pending"
target_version: "v1.5"
---

# 04_live_board_performance_docs — Live Board performance docs

## Objective

Document performance model and payload budgets.

## Context

v1.5 makes SkillLogBoard sustainable for real local research projects by adding performance guardrails, retention/pruning policy, JSONL rotation, compare scalability, and agent-safe operational rules.

## Dependencies

- v1.4 Portable Report Maturity completed or planned separately.
- v1.2/v1.3 Live Board app shell and commercial UI contracts are available.
- Agent Research Layer and Template Forge concepts are available.

## Target Files

- docs/live_board.md
- docs/operational_rules.md
- README.md

## Implementation Steps

1. Explain summary-first model.
2. Explain full-series lazy loading.
3. Explain max run/max point limits.
4. Explain index rebuild command.
5. Document expected large project behavior.

## Acceptance Criteria

- Performance docs exist.
- Payload budgets are documented.
- Index rebuild is documented.

## Verification Commands

```bash
python - <<'PY'
from pathlib import Path
text = Path('docs/operational_rules.md').read_text(encoding='utf-8').lower()
assert 'summary' in text and 'lazy' in text and 'index' in text
print('performance docs check passed')
PY
```

## Non-goals

- Do not make destructive deletion the default behavior.
- Do not require a database for indexing/cache.
- Do not claim SkillLogBoard executes agents automatically.
- Do not implement TensorBoard/W&B import.
- Do not implement Prometheus/Grafana integration.
- Do not implement cloud sync.
- Do not implement multi-user auth.
- Do not add a database backend.
- Do not perform TestPyPI/PyPI publishing in this slice.
- Do not weaken local-first, inspectable-file behavior.

## Handoff Notes

- Keep the slice focused and reviewable.
- Prefer additive metadata/state fields over breaking existing artifact contracts.
- Preserve the separation between portable static evidence and local Live Board app behavior.
- If an item is deferred, document the reason in the Agent Completion Block.
- Update related docs/status/changelog when user-visible behavior changes.

---

## Agent Completion Block

- [ ] Implementation completed
- [ ] Acceptance criteria verified
- [ ] Tests or smoke checks executed
- [ ] No unrelated files changed
- [ ] Notes added below if anything was skipped or deferred

**Status:** PENDING  
**Completed at:**  
**Completed by:**  
**Verification command(s):**  
**Notes:**  

<!-- AGENT_STATUS: PENDING -->

