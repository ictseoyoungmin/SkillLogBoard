---
milestone: "v1.5"
phase: "Performance, Retention, and Operational Rules"
day: "day8"
slice: "03_v15_full_regression"
title: "v1.5 full regression"
priority: "P1"
status: "pending"
target_version: "v1.5"
---

# 03_v15_full_regression — v1.5 full regression

## Objective

Run full regression for performance, retention, and operational rules.

## Context

v1.5 makes SkillLogBoard sustainable for real local research projects by adding performance guardrails, retention/pruning policy, JSONL rotation, compare scalability, and agent-safe operational rules.

## Dependencies

- v1.4 Portable Report Maturity completed or planned separately.
- v1.2/v1.3 Live Board app shell and commercial UI contracts are available.
- Agent Research Layer and Template Forge concepts are available.

## Target Files

- .github/workflows/ci.yml
- tests/
- .devmd/v1.5_performance_retention_operational_rules/**/*.md

## Implementation Steps

1. Run ruff.
2. Run full pytest.
3. Run performance/retention/agent-specific test subsets.
4. Run large demo if environment allows.
5. Run build no-isolation.
6. Confirm GitHub Actions green after push.

## Acceptance Criteria

- Ruff passes.
- Full pytest passes.
- Specific subsets pass.
- Large demo passes or limitation is recorded.
- Build passes.
- Latest CI is green or explicitly noted.

## Verification Commands

```bash
pip install -e ".[dev,dashboard,report,live]"
ruff check .
pytest -q
pytest -q tests/test_project_index.py tests/test_metric_summary_cache.py tests/test_large_project_performance.py tests/test_retention_policy.py tests/test_prune_planner.py tests/test_jsonl_rotation.py tests/test_agent_safety.py tests/test_agent_handoff.py
python examples/live_demo.py --multi-run --runs 80 --rich
python -m build --no-isolation
```

## Non-goals

- Do not make destructive deletion the default behavior.
- Do not require a database for indexing/cache.
- Do not claim SkillLogBoard executes agents automatically.
- Do not implement TensorBoard/W&B import.
- Do not implement Prometheus/Grafana integration.
- Do not implement cloud sync.
- Do not implement multi-user auth.
- Do not add a database backend.
- Do not perform TestPyPI/PyPI publishing in this slice.
- Do not weaken local-first, inspectable-file behavior.

## Handoff Notes

- Keep the slice focused and reviewable.
- Prefer additive metadata/state fields over breaking existing artifact contracts.
- Preserve the separation between portable static evidence and local Live Board app behavior.
- If an item is deferred, document the reason in the Agent Completion Block.
- Update related docs/status/changelog when user-visible behavior changes.

---

## Agent Completion Block

- [ ] Implementation completed
- [ ] Acceptance criteria verified
- [ ] Tests or smoke checks executed
- [ ] No unrelated files changed
- [ ] Notes added below if anything was skipped or deferred

**Status:** PENDING  
**Completed at:**  
**Completed by:**  
**Verification command(s):**  
**Notes:**  

<!-- AGENT_STATUS: PENDING -->

