---
milestone: "v1.5"
phase: "Performance, Retention, and Operational Rules"
day: "day4"
slice: "03_prune_cli_dry_run"
title: "prune CLI dry-run"
priority: "P0"
status: "pending"
target_version: "v1.5"
---

# 03_prune_cli_dry_run — prune CLI dry-run

## Objective

Add prune CLI in dry-run mode.

## Context

v1.5 makes SkillLogBoard sustainable for real local research projects by adding performance guardrails, retention/pruning policy, JSONL rotation, compare scalability, and agent-safe operational rules.

## Dependencies

- v1.4 Portable Report Maturity completed or planned separately.
- v1.2/v1.3 Live Board app shell and commercial UI contracts are available.
- Agent Research Layer and Template Forge concepts are available.

## Target Files

- src/skilllogboard/cli/main.py
- src/skilllogboard/retention/
- tests/test_cli_prune.py
- docs/operational_rules.md

## Implementation Steps

1. Add `skilllog prune PROJECT_DIR --dry-run`.
2. Print table of planned actions.
3. Require explicit flag for destructive behavior if implemented later.
4. Add JSON output if feasible.
5. Add tests.

## Acceptance Criteria

- Prune CLI exists.
- Dry-run is default or strongly required.
- Destructive deletion is guarded.
- Tests pass.

## Verification Commands

```bash
pytest -q tests/test_cli_prune.py
```

## Non-goals

- Do not make destructive deletion the default behavior.
- Do not require a database for indexing/cache.
- Do not claim SkillLogBoard executes agents automatically.
- Do not implement TensorBoard/W&B import.
- Do not implement Prometheus/Grafana integration.
- Do not implement cloud sync.
- Do not implement multi-user auth.
- Do not add a database backend.
- Do not perform TestPyPI/PyPI publishing in this slice.
- Do not weaken local-first, inspectable-file behavior.

## Handoff Notes

- Keep the slice focused and reviewable.
- Prefer additive metadata/state fields over breaking existing artifact contracts.
- Preserve the separation between portable static evidence and local Live Board app behavior.
- If an item is deferred, document the reason in the Agent Completion Block.
- Update related docs/status/changelog when user-visible behavior changes.

---

## Agent Completion Block

- [ ] Implementation completed
- [ ] Acceptance criteria verified
- [ ] Tests or smoke checks executed
- [ ] No unrelated files changed
- [ ] Notes added below if anything was skipped or deferred

**Status:** PENDING  
**Completed at:**  
**Completed by:**  
**Verification command(s):**  
**Notes:**  

<!-- AGENT_STATUS: PENDING -->

