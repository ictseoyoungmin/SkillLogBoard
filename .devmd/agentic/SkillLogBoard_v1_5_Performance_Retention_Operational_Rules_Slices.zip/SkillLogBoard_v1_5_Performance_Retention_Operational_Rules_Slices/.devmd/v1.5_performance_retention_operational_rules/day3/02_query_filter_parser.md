---
milestone: "v1.5"
phase: "Performance, Retention, and Operational Rules"
day: "day3"
slice: "02_query_filter_parser"
title: "query/filter parser"
priority: "P0"
status: "pending"
target_version: "v1.5"
---

# 02_query_filter_parser — query/filter parser

## Objective

Implement lightweight query/filter parser for local runs.

## Context

v1.5 makes SkillLogBoard sustainable for real local research projects by adding performance guardrails, retention/pruning policy, JSONL rotation, compare scalability, and agent-safe operational rules.

## Dependencies

- v1.4 Portable Report Maturity completed or planned separately.
- v1.2/v1.3 Live Board app shell and commercial UI contracts are available.
- Agent Research Layer and Template Forge concepts are available.

## Target Files

- src/skilllogboard/query.py
- tests/test_query_filter.py
- docs/operational_rules.md

## Implementation Steps

1. Support simple filters: status, tag, group, metric threshold if summaries exist, updated range if feasible.
2. Avoid complex query language.
3. Return structured filter errors.
4. Add tests.

## Acceptance Criteria

- Filter parser exists.
- Common filters work.
- Invalid filters return useful errors.
- Tests pass.

## Verification Commands

```bash
pytest -q tests/test_query_filter.py
```

## Non-goals

- Do not make destructive deletion the default behavior.
- Do not require a database for indexing/cache.
- Do not claim SkillLogBoard executes agents automatically.
- Do not implement TensorBoard/W&B import.
- Do not implement Prometheus/Grafana integration.
- Do not implement cloud sync.
- Do not implement multi-user auth.
- Do not add a database backend.
- Do not perform TestPyPI/PyPI publishing in this slice.
- Do not weaken local-first, inspectable-file behavior.

## Handoff Notes

- Keep the slice focused and reviewable.
- Prefer additive metadata/state fields over breaking existing artifact contracts.
- Preserve the separation between portable static evidence and local Live Board app behavior.
- If an item is deferred, document the reason in the Agent Completion Block.
- Update related docs/status/changelog when user-visible behavior changes.

---

## Agent Completion Block

- [ ] Implementation completed
- [ ] Acceptance criteria verified
- [ ] Tests or smoke checks executed
- [ ] No unrelated files changed
- [ ] Notes added below if anything was skipped or deferred

**Status:** PENDING  
**Completed at:**  
**Completed by:**  
**Verification command(s):**  
**Notes:**  

<!-- AGENT_STATUS: PENDING -->

